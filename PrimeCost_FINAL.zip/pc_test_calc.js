// Test: prime.js import+compute vs Excel cached values. Usage: node pc_test_calc.js
const fs=require('fs'),vm=require('vm');
const D=JSON.parse(fs.readFileSync(__dirname+'/pc_data.json','utf8'));
const src=fs.readFileSync(__dirname+'/prime.js','utf8');
const Sheets={};for(const k in D){Sheets[k]=D[k].cells&&!D[k].aoa?{}:{rows:D[k].aoa};}
Sheets['Weekly PnL Mapping']=Object.assign({rows:D['Weekly PnL Mapping'].aoa},D['Weekly PnL Mapping'].cells);
const ctx={console,Math,Date,JSON,Object,Array,String,Number,parseFloat,isFinite,Function,
 XLSX:{utils:{sheet_to_json:ws=>ws.rows}},
 document:{getElementById:()=>null},window:{},getCurrentUser:()=>({email:'a@b',role:'admin'}),normalizeRole:r=>r,db:{}};
vm.createContext(ctx);vm.runInContext(src+';this.PC=PC;',ctx);
const wb={Sheets};
ctx.PC.site='so3';ctx.PC.sites=[{key:'so3',name:'SO3',code:'SO3',company:'Kenjitei'}];ctx.PC.role='admin';ctx.PC.week='2026-11-02';
ctx.PC.setup=vm.runInContext('pcSetupFill()',ctx);ctx.PC.W=vm.runInContext("pcNewWeek('2026-11-02')",ctx);
const r=vm.runInContext('pcImportWb',ctx)(wb,true);console.log(r.msg);
const S=ctx.PC.setup,W=ctx.PC.W,RT=ctx.PC.rates;
const R=vm.runInContext('pcCalc',ctx)(S,W,RT);
const exp={grossT:713846.58,netT:595296.09+93784.81,foodCost:242880.4372,'mgmt':85661.5896,hourly:89413.74808,laborT:175075.3377,prime:417955.7748,gm:295890.8052};
let fail=0;for(const k in exp){const ok=Math.abs(R[k]-exp[k])<1;if(!ok)fail++;console.log(ok?'PASS':'FAIL',k,R[k],'expected',exp[k]);}
console.log('beg',R.beg,'end',R.end,'purchases',R.purchases,'petty',JSON.stringify(R.pettyBy));
console.log(fail?fail+' FAIL':'ALL PASS');
