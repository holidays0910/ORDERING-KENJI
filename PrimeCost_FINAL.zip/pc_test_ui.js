// UI smoke test: renders every Prime Cost tab with mock Firestore. Usage: node pc_test_ui.js
const {chromium}=require('playwright');const fs=require('fs');
(async()=>{
const b=await chromium.launch();const fails=[];
async function run(role,branch){
 const p=await b.newPage({viewport:{width:400,height:800}});const errs=[];
 p.on('pageerror',e=>errs.push(e.message));p.on('console',m=>{if(m.type()==='error'&&!/ERR_TUNNEL|net::ERR/.test(m.text()))errs.push(m.text())});
 await p.setContent('<style>'+fs.readFileSync(__dirname+'/style.css','utf8')+'</style><div id="pc-root"></div>');
 await p.evaluate(({role,branch})=>{
  window.__store={inventory_branches:{a:{branch:'SO3',code:'SO3',company:'Kenjitei'},b:{branch:'SO4',code:'SO4',company:'Tanoshi'}}};
  const S=window.__store;
  const col=n=>({get:async()=>{const o=S[n]||{};return {forEach:f=>Object.keys(o).forEach(k=>f({id:k,data:()=>o[k]}))}},doc:id=>({get:async()=>({exists:!!(S[n]&&S[n][id]),data:()=>(S[n]||{})[id]}),set:async(d,opt)=>{S[n]=S[n]||{};S[n][id]=opt&&opt.merge?Object.assign(S[n][id]||{},d):d}})});
  window.db={collection:col};
  window.getCurrentUser=()=>({email:'m@x',role,branch});window.normalizeRole=r=>r;window.logSystemAction=async()=>{};
  window.alert=m=>{window.__alert=m};window.arModal=h=>{window.__modal=h};window.arCloseModal=()=>{};
 },{role,branch});
 await p.addScriptTag({content:fs.readFileSync(__dirname+'/prime.js','utf8')});
 await p.evaluate(()=>loadPrime());
 return {p,errs};
}
// manager ng SO3
let {p,errs}=await run('branch','SO3');
const tabs=await p.evaluate(()=>pcTabs().map(t=>t[0]));
console.log('tabs (manager):',tabs.join(','));
for(const t of tabs){await p.evaluate(t=>{PC.tab=t;pcRender()},t);const n=await p.evaluate(()=>document.getElementById('pc-root').innerText.length);if(n<20)fails.push('empty tab '+t);}
// manager makes edit + save
await p.evaluate(()=>{PC.tab='sales';pcRender();PC.W.sales.vat[0]=1000;pcDirty();return pcSave()});
const saved=await p.evaluate(()=>Object.keys(__store.pc_weeks||{}));console.log('saved',saved);if(!saved.length||!saved[0].startsWith('so3__'))fails.push('save');
console.log('manager can edit:',await p.evaluate(()=>pcCan()));
console.log('sites seen by manager:',await p.evaluate(()=>PC.sites.map(s=>s.name)));
console.log('setup visible to manager:',tabs.includes('setup'));
const ov=await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth+2);if(ov)fails.push('h-overflow 400px');
errs.forEach(e=>fails.push('pageerror '+e));
// staff
({p,errs}=await run('branch staff','SO3'));
console.log('staff can edit:',await p.evaluate(()=>pcCan()));
if(await p.evaluate(()=>pcCan()))fails.push('staff can edit');
// admin
({p,errs}=await run('admin',''));
const at=await p.evaluate(()=>pcTabs().map(t=>t[0]));console.log('admin tabs',at.join(','));
for(const t of at){await p.evaluate(t=>{PC.tab=t;pcRender()},t);}
errs.forEach(e=>fails.push('admin pageerror '+e));
console.log(fails.length?'FAIL: '+fails.join(' | '):'ALL PASS');await b.close();})();
