# KusinaERP — Prime Cost Management (progress notes)

## Status (Nov 13)
- prime.js (456 lines, 94 functions, no undefined refs, syntax OK) — wired in: admin.html (menu data-module="prime", view-admin-prime/#pc-root, script), branch.html (menu "Prime Cost", view-branch-prime, script), app.js (switchAdminView/switchBranchView 'prime' -> loadPrime(); ACCESS_MODULES key 'prime'), firestore.rules (pc_weeks, pc_setup, pc_rates, pc_ratesecure[admin only], pc_actual).
- DONE: pc_test_calc.js — import + pcCalc vs Excel cached values: ALL PASS (gross, net, food cost, mgmt, hourly, labor, prime cost, gross margin; petty cash cats match).
- DONE: pc_test_ui.js — Playwright + mock Firestore: lahat ng tab nagre-render (manager/admin), manager nakaka-save sa pc_weeks/so3__<monday>, staff HINDI makaka-edit, Setup/Lahat ng Branch admin lang, walang page error. (Run: node pc_test_ui.js sa folder na may style.css + prime.js)
- NOT YET DONE: regression run of old tests, real-Firebase test.

## Collections
pc_weeks/{site}__{monday} (sales, covers, channels, inv log, petty, food, other, labor rows, plan, fc, invc beg/end, locked)
pc_setup/{site} (mgmt %, rent, fixed costs, channels) · pc_rates/{site} (hourly only) · pc_ratesecure/{site} (sahod breakdown, admin only) · pc_actual/{site}__{monday}

## Edit rules
Manager ng branch na iyon (+Admin) lang ang nag-eedit ng linggo; Setup/rates/actual P&L = Admin; locked week = read-only.

## Excel cached values to verify (Prime Cost Worksheet, SO3, Nov 2-8 2026)
Vatable 595,296.09 | Vat-exempt 93,784.81 | SC 17,081.30 | PWD 6,824.63 | Sales Disc 359.75 | Comp 500 | Gross 713,846.58
Cost of sales (food) 242,880.44 = 34.02% (BEG 273,206.75, END 248,939.44)
Management 12% = 85,661.59 | Hourly 89,413.75 (12.53%) | Taxes 0 | Total labor 175,075.34 (24.53%)
Prime cost 417,955.77 (58.55%) | Gross margin after prime 295,890.81 (41.45%)
Delivery/bank fees area rows 32-39 (Grab 93,835 -> 16,890.30 @18%; FoodPanda 378,141.17 @23.5%...)
Petty cash cats: Advertising 101.75, Meals 4,045.91, Cleaning 354.91, Kitchen 695.95, Office 1,154.65, EQP R&M 186.30, Travel 400, Postage 3,481.57

## Excel sheets -> ERP tab
Purchases -> Purchases · Petty Cash Form/PCF Food/Other expenses -> Petty Cash/Other · Labor Hours/Cost/Rate -> Labor (+Setup rates) · New Beginning/Ending Inventory, Total Food Cost -> Inventory (vs ERP count) · P_ sheets -> Forecast/planned labor · Weekly PnL Report/Mapping -> P&L + Setup · hidden (deductions, allowances, de minimis, SSS/PhilHealth/HDMF/HMO/13th) -> Setup > Rates (admin only)

## Helper
dump.py <sheet> <maxrow> — prints formulas + cached values of the Excel (in scratchpad/out).
